---
name: Aetheris Flight Collective
colors:
  surface: '#111415'
  surface-dim: '#111415'
  surface-bright: '#373a3b'
  surface-container-lowest: '#0c0f10'
  surface-container-low: '#191c1d'
  surface-container: '#1d2021'
  surface-container-high: '#282a2b'
  surface-container-highest: '#323536'
  on-surface: '#e1e3e4'
  on-surface-variant: '#c6c6ce'
  inverse-surface: '#e1e3e4'
  inverse-on-surface: '#2e3132'
  outline: '#909098'
  outline-variant: '#46464d'
  surface-tint: '#bfc5e4'
  primary: '#bfc5e4'
  on-primary: '#292f48'
  primary-container: '#0a1128'
  on-primary-container: '#767c99'
  inverse-primary: '#575d78'
  secondary: '#83cfff'
  on-secondary: '#00344b'
  secondary-container: '#03a8e8'
  on-secondary-container: '#003952'
  tertiary: '#e9c349'
  on-tertiary: '#3c2f00'
  tertiary-container: '#cba72f'
  on-tertiary-container: '#4e3d00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#bfc5e4'
  on-primary-fixed: '#141a32'
  on-primary-fixed-variant: '#3f465f'
  secondary-fixed: '#c6e7ff'
  secondary-fixed-dim: '#83cfff'
  on-secondary-fixed: '#001e2d'
  on-secondary-fixed-variant: '#004c6b'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#111415'
  on-background: '#e1e3e4'
  surface-variant: '#323536'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

The design system is engineered to evoke the precision of modern aviation and the exclusivity of a premium travel concierge. The brand personality is rooted in **Modern Elegance**, balancing the technical reliability of a flight booking engine with the aspirational quality of high-end travel.

The visual style follows a **Modern Glassmorphic** approach. It utilizes deep, saturated foundations to provide a sense of security and prestige, contrasted with vibrant accents and translucent overlays that mimic the light and atmospheric qualities of high-altitude flight. High-impact whitespace is treated as a premium commodity, ensuring a calm, clutter-free user journey that prioritizes the user's cognitive ease.

## Colors

The palette is designed for high-fidelity dark mode environments, using depth and luminance to guide the eye.

- **Midnight Navy (#0A1128):** The primary foundation. Used for backgrounds and deep structural elements to establish a trustworthy, night-sky aesthetic.
- **Electric Sky Blue (#00A8E8):** The primary action color. Used for interactive states, progress indicators, and essential navigation cues.
- **Royal Gold (#D4AF37):** Reserved for "Premium" or "First Class" tiering, loyalty status indicators, and high-value call-to-actions.
- **Surface Neutrals:** An array of cool-toned greys derived from the primary navy are used to define surface hierarchies without breaking the immersive dark environment.

## Typography

This design system utilizes **Inter** for its exceptional legibility and neutral, systematic character. The hierarchy is strictly enforced to manage complex flight data without overwhelming the user.

- **Headlines:** Use tighter letter-spacing and bold weights to create a sense of authority. 
- **Data Points:** Flight numbers, times, and prices should use `headline-md` or `body-lg` with medium weights to ensure they stand out against UI chrome.
- **Labels:** Small caps with increased tracking are used for metadata (e.g., "DEPARTURE," "TERMINAL") to differentiate technical data from prose.

## Layout & Spacing

The layout employs a **Fluid Grid** system with generous margins to maintain a high-end editorial feel. 

- **Desktop:** 12-column grid with 24px gutters and 64px outer margins. Content containers for search results should be centered with a max-width of 1280px.
- **Tablet:** 8-column grid with 24px gutters and 32px outer margins.
- **Mobile:** 4-column grid with 16px gutters and 16px outer margins. 

Vertical rhythm follows an 8px base unit. Larger sections are separated by `lg` (48px) or `xl` (80px) units to allow the "premium" photography to breathe.

## Elevation & Depth

Depth is primarily communicated through **Glassmorphism** and **Tonal Layering** rather than traditional heavy shadows.

- **Base Layer:** Midnight Navy (#0A1128).
- **Surface Layer (Glass):** Used for search panels and flight cards. Background-blur (20px) with a 10% white tint and a subtle 1px inner border (white at 15% opacity) to simulate frosted glass.
- **Active Elevation:** When a flight card is selected or hovered, a soft glow using the primary accent color (#00A8E8) with 20% opacity and a 30px blur is applied behind the element to indicate "lift."
- **Overlays:** Full-screen modals use a 60% opacity Midnight Navy backdrop blur to keep the user focused on the task.

## Shapes

The shape language is sophisticated and modern. A consistent **12px (rounded-lg)** corner radius is applied to all primary containers, buttons, and input fields. 

- **Secondary Elements:** Smaller components like chips or tags use the standard `rounded` (8px) setting.
- **Iconography:** Use linear, 2px stroke icons with slightly rounded caps to match the typography's geometric nature. 
- **Buttons:** Primary buttons use the 12px radius, while "Pill" shapes are reserved exclusively for status indicators (e.g., "On Time," "Delayed").

## Components

### Buttons
- **Primary:** Gradient fill (Electric Sky Blue to a slightly darker shade), 12px radius, white text. On hover, the gradient brightness increases by 10%.
- **Secondary:** Ghost style with a 1px Electric Sky Blue border and 12px radius.
- **Premium:** Royal Gold fill with a subtle metallic sheen effect, reserved for "Upgrade" or "Book First Class" actions.

### Search Inputs
Fields should feature a 1px semi-transparent border. Upon focus, the border glows Electric Sky Blue. Use clear, high-contrast labels positioned above the field or floating.

### Flight Cards
The centerpiece of the UI. Utilize the glassmorphism effect. The card is divided into three zones:
1. **Journey Info:** Large typography for city codes (LHR → JFK).
2. **Details:** Clear, labeled rows for duration and stops.
3. **Action:** Price and "Select" button anchored to the right.

### Progress Steppers
A thin, 2px line using Electric Sky Blue. Completed steps feature a glowing dot, while upcoming steps are desaturated navy.

### Chips & Tags
Small, 8px rounded corners. Used for flight features (e.g., "WiFi," "Extra Legroom"). Backgrounds should be a low-opacity tint of the neutral color to ensure they remain secondary to the main journey info.