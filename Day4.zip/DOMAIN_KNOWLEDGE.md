# International Smile — Domain Knowledge (Day 4)

Slice: **Flight Search request**. Built by live-observing IndiGo's real
production search widget (`https://goindigo.in`), not by inferring from
memory — every field below is tagged with its evidence source, per the
verify-before-generate methodology agreed this session. Nothing here is
implemented until it has (1) a cited source, (2) a failing test, (3) code
that turns it green, (4) a review pass.

Companion files in this folder:
- `src/international_smile/flight_search.py` — the Pydantic v2 model this
  doc specifies (written *after* the test, per RED→GREEN→REFACTOR)
- `tests/test_flight_search.py` — the test that pinned the spec before any
  implementation existed
- `REVIEW.md` — the review pass log for this slice

---

## Evidence source key

- **[Observed]** — captured live from `goindigo.in` in this session via
  browser automation (`read_page` accessibility tree + `get_page_text`).
  Exact widget state, not a screenshot guess.
- **[Inferred]** — standard OTA/booking-domain pattern, not verified on
  IndiGo directly this session. Flagged so it isn't mistaken for observed
  fact.
- **[Stitch]** — from the delivered UI mockup
  (`stitch_modern_irctc_redesign/search_flights/code.html`), included only
  where it conflicts with or extends the observed IndiGo structure.

---

## 1. Flight Search — field structure

### 1.1 Trip type — **[Observed]**
Radio group, 3 mutually exclusive options (not 2, as the Stitch mock
shows — see conflict note below):
```
radio "oneWay"
radio "roundTrip"
radio "multiCity"
```
Captured directly from IndiGo's live accessibility tree. `multiCity` has
**no equivalent anywhere in the Stitch mock** (`search_flights/code.html`
only has `oneWay`/`roundTrip`, lines 170-176) — this is a real gap in the
delivered design, not an inference.

### 1.2 Origin / Destination — **[Observed]**
Live page text showed the combined presentation format:
```
From
Delhi, DEL
Indira Gandhi International Airport
```
i.e. three data points bound to one field: **city name**, **IATA code**,
**full airport name**. A search field must resolve free-text input to all
three, not just a code — needed for autocomplete matching and for display
after selection.

### 1.3 Dates — **[Observed]**
```
button "departureDate 22 August 2026"
button "Arrival date, no date selected, editable — Offer available: Save more and enjoy up to ₹1000 off!"
```
Two real details the Stitch mock has no equivalent for:
- The return-date control **carries a live promotional message** inline
  ("Save more and enjoy up to ₹1000 off!") — merchandising is coupled to
  the date field itself, not a separate banner.
- Departure date is **pre-populated** on load (today+ default), return is
  not — matches a round-trip default assumption, but return stays opt-in.

### 1.4 Travellers + Fare type — **[Observed]**
```
Travellers + Special Fares
1 Passenger
₹ INR
6Exclusive   Offer
Students     Offer
Family & Friends  Offer
```
This is **one combined field**, not two separate "passenger count" and
"cabin class" controls like the Stitch mock implies
(`search_flights/code.html:179-186`, two separate buttons: "1 Passenger"
and "Economy"). IndiGo bundles passenger count with a **currency selector**
and **three named special-fare programs** (`6Exclusive`, `Students`,
`Family & Friends`) inside the same control. None of these three fare
programs exist in the Stitch mock at all — confirmed absent by reading
`search_flights/code.html` in full (no matching text anywhere in that
file).

### 1.5 Payment method pre-selector — **[Observed]**
```
Pay with — Cash
```
IndiGo exposes a "pay with" mode selector *on the search form itself*
(Cash vs., implicitly, points/BluChip loyalty currency) — before any
flight is even selected. No equivalent anywhere in the Stitch funnel,
where payment method only appears at `checkout/`.

### 1.6 Promo code — **[Observed]**
```
+ ADD PROMOCODE
```
A collapsed, optional text-entry affordance on the search form itself —
not deferred to checkout as in the Stitch mock.

### 1.7 Search action — **[Observed]**
```
button "Search" type="button"
```
Confirmed `type="button"`, not `type="submit"` — same non-native-form
pattern as the Stitch mock's own login CTA
(`login/code.html:195`, also `type="button"`). This is a real,
cross-product convention worth keeping: search/booking actions are
JS-driven fetches, not native form posts (so client-side validation must
run before the fetch fires, not rely on HTML5 form validation).

---

## 2. Conflicts between [Observed] IndiGo and [Stitch] mock (must be resolved, not silently picked)

| Field | Stitch mock | IndiGo (Observed) | Decision needed |
|---|---|---|---|
| Trip type | 2 options (One way / Round trip) | 3 options (+ Multi City) | Add Multi City, or explicitly scope it out — do not silently drop it |
| Passenger + cabin | 2 separate buttons | 1 combined control + currency + special fares | Combine, and decide whether International Smile carries special-fare programs at launch |
| Payment mode | Only at checkout | Exposed at search (Cash vs. loyalty currency) | Decide whether a "pay with points" concept applies to International Smile at all |
| Promo code | Not present pre-checkout | Present at search | Decide placement |

None of these are resolved by this document — they are staged as open
decisions per the "never silently pick" rule from earlier in this session.

---

## 3. What is still [Inferred], not observed, in this slice

- Server-side validation rules (min/max passengers, date-range limits,
  same-origin/destination rejection) — not visible in a static DOM read;
  inferred from standard booking-domain practice. Encoded in the Pydantic
  model below as constraints, but flagged here as **not IndiGo-verified**,
  just reasonable defaults pending real confirmation (e.g. by attempting
  an actual invalid search on IndiGo and reading its error response —
  not done in this pass).

---

## 4a. Search RESULTS slice (Prompt9) — decisions and reference-check status

**Reference check status: capped, not completed.** Attempted a live check
of IndiGo's actual results-page structure for this pass; a guessed deep-
link URL 404'd and the homepage search widget did not converge to results
within the "5 min max" cap this process itself sets. Per the process's own
rule (don't burn unbounded time on step 2), this was cut short rather than
extended — the result-card shape below is `[Inferred]` from the fare-tier
naming already `[Observed]` in an earlier pass of this session (SAVER /
FLEXI PLUS / SUPER 6E, `+15kg` baggage pricing, `6E####` flight-number
format), not freshly re-verified against a live results page.

**The 4 open conflicts from §2, resolved pragmatically for this slice
(flagged, not silently absorbed):**
| Conflict | Decision for this pass | Status |
|---|---|---|
| Multi City trip type | `FlightSearchRequest` already accepts it (tested); this pass's route accepts it too but returns the same single-leg mock result set — true multi-leg itinerary construction is NOT implemented | Deferred |
| Special-fare programs (6Exclusive/Student/Family&Friends) | Out of scope for this slice | Deferred |
| Pay-with-points / loyalty currency | Out of scope for this slice | Deferred |
| Promo-code placement | Kept at search time (matches `FlightSearchRequest.promo_code`, already modeled) | Resolved |

These are product-scope decisions made to keep this slice shippable, not
technical dead-ends — each deferred item needs an explicit user go/no-go
before a future slice implements it for real.

## 4. The vertical slice for this session: `FlightSearchRequest`

Scope intentionally narrow — **only** the search-request shape, not the
full funnel — to keep to the "1 test proving it → 1 review pass" unit size
agreed as the working methodology.

**RED→GREEN evidence:** `tests/test_flight_search.py` was written and run
against no implementation first (confirmed failing with
`ModuleNotFoundError`), then `src/international_smile/flight_search.py`
was written to make it pass. See `REVIEW.md` for the actual command output
of both runs.
