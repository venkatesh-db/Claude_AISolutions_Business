import os
import uuid

os.environ.setdefault("JWT_SECRET", "test-secret-for-pytest-only")
os.environ.setdefault(
    "DATABASE_URL", "postgresql+asyncpg://travel:travel@localhost:5433/travel"
)
os.environ.setdefault("REDIS_URL", "redis://localhost:6379/0")

import pytest_asyncio
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from app.config import settings
from app.database import Base


@pytest_asyncio.fixture
async def db_engine():
    engine = create_async_engine(settings.database_url)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
def db_sessionmaker(db_engine):
    return async_sessionmaker(db_engine, expire_on_commit=False)


@pytest_asyncio.fixture
def unique_phone():
    return f"+1{uuid.uuid4().int % 10**10:010d}"
