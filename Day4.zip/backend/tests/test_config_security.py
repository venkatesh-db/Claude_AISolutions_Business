"""RED step for finding 1 (Day4/PROMPT8_fix_findings.md):
hardcoded default JWT secret in app/config.py.

Proves the unsafe path is actually blocked, not just that the literal
default string is gone from the source.
"""

import importlib

import pytest


def _reload_settings_module():
    import app.config as config_module

    importlib.reload(config_module)
    return config_module


def test_missing_jwt_secret_raises_at_import(monkeypatch):
    monkeypatch.delenv("JWT_SECRET", raising=False)
    with pytest.raises(RuntimeError, match="JWT_SECRET"):
        _reload_settings_module()


def test_explicit_jwt_secret_is_accepted(monkeypatch):
    monkeypatch.setenv("JWT_SECRET", "a-real-secret-from-env")
    config_module = _reload_settings_module()
    assert config_module.settings.jwt_secret == "a-real-secret-from-env"  # noqa: S105 (test fixture value, not a real secret)
