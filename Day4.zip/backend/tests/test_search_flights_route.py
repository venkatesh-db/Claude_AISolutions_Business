"""RED step for Prompt9: POST /search/flights route.

FlightSearchRequest (src/international_smile/flight_search.py) already has
its own tested contract (Day4/tests/test_flight_search.py, 11 passing).
This tests the NEW route that wraps it and returns FlightOption results,
per DOMAIN_KNOWLEDGE.md §4a -- fare-tier names/format are [Inferred] from
an earlier [Observed] IndiGo pass, not freshly re-verified this pass.
"""

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)

VALID_SEARCH = {
    "trip_type": "oneWay",
    "origin": "DEL",
    "destination": "BOM",
    "departure_date": "2026-08-25",
    "adults": 1,
}


def test_search_returns_flight_options():
    res = client.post("/search/flights", json=VALID_SEARCH)
    assert res.status_code == 200
    body = res.json()
    assert "results" in body
    assert len(body["results"]) >= 1


def test_search_result_has_indigo_style_flight_number_format():
    res = client.post("/search/flights", json=VALID_SEARCH)
    for option in res.json()["results"]:
        assert option["flight_number"].startswith("6E")


def test_search_result_has_three_fare_tiers():
    res = client.post("/search/flights", json=VALID_SEARCH)
    for option in res.json()["results"]:
        tier_names = {t["name"] for t in option["fare_tiers"]}
        assert tier_names == {"SAVER", "FLEXI PLUS", "SUPER 6E"}


def test_search_rejects_same_origin_and_destination():
    bad = {**VALID_SEARCH, "destination": "DEL"}
    res = client.post("/search/flights", json=bad)
    assert res.status_code == 422


def test_search_rejects_round_trip_missing_return_date():
    bad = {**VALID_SEARCH, "trip_type": "roundTrip"}
    res = client.post("/search/flights", json=bad)
    assert res.status_code == 422


def test_search_accepts_multi_city_but_returns_deferred_scope_flag():
    """DOMAIN_KNOWLEDGE.md §4a: Multi City is accepted, not fully
    implemented -- the route must say so explicitly, not silently return
    a single-leg result as if it were a complete itinerary."""
    multi = {**VALID_SEARCH, "trip_type": "multiCity"}
    res = client.post("/search/flights", json=multi)
    assert res.status_code == 200
    assert res.json()["scope_note"] is not None
