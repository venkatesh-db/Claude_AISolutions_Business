"""RED step for finding 2 (Day4/PROMPT8_fix_findings.md):
unhandled race on user creation in auth_service._get_or_create_user
(the SELECT-then-INSERT step inside verify_otp).

Runs two DB sessions concurrently via asyncio.gather against a real
Postgres connection -- the SELECT and the later INSERT/flush are separate
network round-trips, so the event loop genuinely interleaves them between
awaits, reproducing the same race a double-tap or client retry hits in
production. This is the standard way to exercise a check-then-act race in
an integration test: real I/O interleaving, not a simulated one.
"""

import asyncio

import pytest

from app.services import auth_service


@pytest.mark.asyncio
async def test_concurrent_get_or_create_user_does_not_raise(db_sessionmaker, unique_phone):
    async def race_participant() -> str:
        async with db_sessionmaker() as session:  # type: AsyncSession
            user, _is_new = await auth_service._get_or_create_user(session, unique_phone)
            await session.commit()
            return str(user.id)

    results = await asyncio.gather(race_participant(), race_participant(), return_exceptions=True)

    errors = [r for r in results if isinstance(r, BaseException)]
    assert not errors, f"concurrent user creation raised: {errors}"

    user_ids = {r for r in results}
    assert len(user_ids) == 1, "both calls must resolve to the same user row, not two rows"
