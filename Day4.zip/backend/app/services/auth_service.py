"""Login domain logic. State machine: ANONYMOUS -> OTP_PENDING -> AUTHENTICATED,
with OTP_LOCKED as a terminal sub-state on repeated failed verification.
Reconstructed for Day4 from the same contract verified earlier this session
(irctc-travel-app/backend/app/services/auth_service.py, since removed from
disk by an external process outside this session — see REVIEW.md).
"""

import logging
import secrets
import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app import redis_client
from app.config import settings
from app.core.security import create_access_token, hash_token, new_opaque_token
from app.models.user import RefreshToken, User


class OtpRequestRateLimited(Exception):
    pass


class OtpExpired(Exception):
    pass


class OtpLocked(Exception):
    def __init__(self, retry_after: int) -> None:
        self.retry_after = retry_after


class OtpCodeInvalid(Exception):
    def __init__(self, attempts_remaining: int) -> None:
        self.attempts_remaining = attempts_remaining


def _otp_key(session_id: uuid.UUID) -> str:
    return f"otp:session:{session_id}"


def _rate_limit_key(phone: str) -> str:
    return f"otp:ratelimit:{phone}"


def _lock_key(session_id: uuid.UUID) -> str:
    return f"otp:lock:{session_id}"


async def request_otp(phone: str) -> tuple[uuid.UUID, int, int]:
    redis = redis_client.get_redis()

    rl_key = _rate_limit_key(phone)
    count = await redis.incr(rl_key)
    if count == 1:
        await redis.expire(rl_key, settings.otp_request_window_seconds)
    if count > settings.otp_request_max_per_window:
        raise OtpRequestRateLimited

    session_id = uuid.uuid4()
    code = f"{secrets.randbelow(1_000_000):06d}"
    await redis.hset(
        _otp_key(session_id),
        mapping={"phone": phone, "code_hash": hash_token(code), "attempts": "0"},
    )
    await redis.expire(_otp_key(session_id), settings.otp_ttl_seconds)

    # Demo-only: in production this is sent via SMS gateway, never logged/returned.
    logging.getLogger(__name__).info("OTP for %s (session %s): %s", phone, session_id, code)

    return session_id, settings.otp_ttl_seconds, 30


async def verify_otp(db: AsyncSession, session_id: uuid.UUID, code: str) -> tuple[User, bool]:
    redis = redis_client.get_redis()

    lock_ttl = await redis.ttl(_lock_key(session_id))
    if lock_ttl and lock_ttl > 0:
        raise OtpLocked(retry_after=lock_ttl)

    data = await redis.hgetall(_otp_key(session_id))
    if not data:
        raise OtpExpired

    if hash_token(code) != data["code_hash"]:
        attempts = await redis.hincrby(_otp_key(session_id), "attempts", 1)
        remaining = settings.otp_max_attempts - attempts
        if remaining <= 0:
            await redis.set(_lock_key(session_id), "1", ex=settings.otp_lock_seconds)
            await redis.delete(_otp_key(session_id))
            raise OtpLocked(retry_after=settings.otp_lock_seconds)
        raise OtpCodeInvalid(attempts_remaining=remaining)

    phone = data["phone"]
    await redis.delete(_otp_key(session_id))

    return await _get_or_create_user(db, phone)


async def _get_or_create_user(db: AsyncSession, phone: str) -> tuple[User, bool]:
    """Race-safe get-or-create. A concurrent call for the same brand-new
    phone (double-tap, client retry) can both pass the initial SELECT;
    the DB's unique constraint on `phone` then rejects the loser's INSERT
    with IntegrityError instead of silently duplicating a row -- caught
    here and resolved by re-fetching the winner's row, rather than
    surfacing as an unhandled 500. Returns (user, is_new_user).
    """
    result = await db.execute(select(User).where(User.phone == phone))
    user = result.scalar_one_or_none()
    if user is not None:
        return user, False

    user = User(phone=phone)
    db.add(user)
    try:
        await db.flush()
        return user, True
    except IntegrityError:
        await db.rollback()
        result = await db.execute(select(User).where(User.phone == phone))
        return result.scalar_one(), False


async def issue_token_pair(db: AsyncSession, user: User) -> tuple[str, str, int]:
    access_token = create_access_token(user.id)
    refresh_token = new_opaque_token()
    family_id = uuid.uuid4()

    db.add(
        RefreshToken(
            user_id=user.id,
            family_id=family_id,
            token_hash=hash_token(refresh_token),
            expires_at=datetime.now(UTC) + timedelta(seconds=settings.refresh_token_ttl_seconds),
        )
    )
    return access_token, refresh_token, settings.access_token_ttl_seconds
