from uuid import UUID

from pydantic import BaseModel, Field


class OtpRequestIn(BaseModel):
    phone: str = Field(pattern=r"^\+[1-9]\d{7,14}$")


class OtpRequestOut(BaseModel):
    otp_session_id: UUID
    expires_in: int
    resend_after: int


class OtpVerifyIn(BaseModel):
    otp_session_id: UUID
    code: str = Field(min_length=6, max_length=6, pattern=r"^\d{6}$")


class UserPublicOut(BaseModel):
    id: UUID
    phone: str
    is_new_user: bool


class TokenPairOut(BaseModel):
    access_token: str
    refresh_token: str
    expires_in: int
    user: UserPublicOut
