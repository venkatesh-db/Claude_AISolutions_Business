from pydantic import BaseModel


class FareTier(BaseModel):
    name: str
    price_inr: int


class FlightOption(BaseModel):
    flight_number: str
    origin: str
    destination: str
    departure_time: str
    arrival_time: str
    fare_tiers: list[FareTier]


class SearchResponse(BaseModel):
    results: list[FlightOption]
    scope_note: str | None = None
