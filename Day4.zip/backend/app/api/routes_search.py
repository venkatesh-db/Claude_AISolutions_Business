"""Search Flights route (Prompt9). Wraps the already-tested
FlightSearchRequest contract (src/international_smile/flight_search.py)
and returns mock FlightOption results -- no live GDS/fare integration in
this slice, per DOMAIN_KNOWLEDGE.md §4a.
"""

from fastapi import APIRouter
from international_smile.flight_search import FlightSearchRequest, TripType

from app.schemas.search import FareTier, FlightOption, SearchResponse

router = APIRouter(prefix="/search", tags=["search"])

_MOCK_FARE_TIERS = [
    FareTier(name="SAVER", price_inr=4850),
    FareTier(name="FLEXI PLUS", price_inr=6200),
    FareTier(name="SUPER 6E", price_inr=8900),
]


@router.post("/flights", response_model=SearchResponse)
async def search_flights(body: FlightSearchRequest) -> SearchResponse:
    result = FlightOption(
        flight_number="6E2341",
        origin=body.origin,
        destination=body.destination,
        departure_time="09:15",
        arrival_time="11:30",
        fare_tiers=_MOCK_FARE_TIERS,
    )

    scope_note = None
    if body.trip_type is TripType.MULTI_CITY:
        scope_note = (
            "Multi City search is accepted but not fully implemented in this slice — "
            "results shown are for the first leg only, not a complete multi-leg itinerary."
        )

    return SearchResponse(results=[result], scope_note=scope_note)
