from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas.auth import (
    OtpRequestIn,
    OtpRequestOut,
    OtpVerifyIn,
    TokenPairOut,
    UserPublicOut,
)
from app.services import auth_service

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/otp/request", response_model=OtpRequestOut, status_code=status.HTTP_202_ACCEPTED)
async def otp_request(body: OtpRequestIn) -> OtpRequestOut:
    try:
        session_id, expires_in, resend_after = await auth_service.request_otp(body.phone)
    except auth_service.OtpRequestRateLimited as exc:
        raise HTTPException(status_code=status.HTTP_429_TOO_MANY_REQUESTS, detail="rate_limited") from exc
    return OtpRequestOut(otp_session_id=session_id, expires_in=expires_in, resend_after=resend_after)


@router.post("/otp/verify", response_model=TokenPairOut)
async def otp_verify(body: OtpVerifyIn, db: AsyncSession = Depends(get_db)) -> TokenPairOut:
    try:
        user, is_new_user = await auth_service.verify_otp(db, body.otp_session_id, body.code)
    except auth_service.OtpExpired as exc:
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="otp_expired") from exc
    except auth_service.OtpLocked as exc:
        raise HTTPException(
            status_code=status.HTTP_423_LOCKED,
            detail={"error": "otp_locked", "retry_after": exc.retry_after},
        ) from exc
    except auth_service.OtpCodeInvalid as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_code", "attempts_remaining": exc.attempts_remaining},
        ) from exc

    access_token, refresh_token, expires_in = await auth_service.issue_token_pair(db, user)
    await db.commit()

    return TokenPairOut(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=expires_in,
        user=UserPublicOut(id=user.id, phone=user.phone, is_new_user=is_new_user),
    )
