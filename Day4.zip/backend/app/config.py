from pydantic import ValidationError
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    database_url: str = "postgresql+asyncpg://travel:travel@localhost:5432/travel"
    redis_url: str = "redis://localhost:6379/0"

    jwt_secret: str
    jwt_algorithm: str = "HS256"
    access_token_ttl_seconds: int = 900
    refresh_token_ttl_seconds: int = 60 * 60 * 24 * 7

    otp_ttl_seconds: int = 300
    otp_max_attempts: int = 5
    otp_lock_seconds: int = 900
    otp_request_max_per_window: int = 3
    otp_request_window_seconds: int = 600


try:
    settings = Settings()  # type: ignore[call-arg]  # jwt_secret comes from the environment, not a literal arg
except ValidationError as exc:
    raise RuntimeError(
        "JWT_SECRET must be set in the environment — no insecure default is provided. "
        f"Original error: {exc}"
    ) from exc
