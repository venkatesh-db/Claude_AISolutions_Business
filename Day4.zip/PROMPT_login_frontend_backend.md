Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

We work in single verified vertical slices, never big-bang generation.
Methodology for this slice, follow it exactly, in order:

1. READ BOTH SIDES FIRST. Read the existing frontend markup at
   stitch_modern_irctc_redesign/login/code.html in full before touching
   anything. Confirm what actually exists: the Apple/Google buttons
   (currently no handler), the mobile-number input with a hardcoded "+1"
   prefix, the "Send One-Time Code" button (currently type="button", no
   JS wired, no OTP-entry step exists at all). Read the existing backend
   login/OTP code that's already been built. Do not assume either side's
   shape — confirm both by reading, and tell me what you found before
   proceeding.

2. REFERENCE CHECK (5 min max): verify live on goindigo.in (or
   MakeMyTrip/Goibibo) how a real OTA actually wires this: what the
   request/response looks like for "send OTP," what happens on wrong
   OTP, what the resend-timer behavior is. Use the browser tool, observe
   live, don't rely on memorized knowledge.

3. DOMAIN_KNOWLEDGE.md: extend it with the exact contract between this
   frontend and backend — every field tagged [Observed] / [Stitch] /
   [Inferred] as usual. Specifically pin down:
   - Request shape frontend sends on "Send One-Time Code" click
     (mobile number + country code — note the mock hardcodes "+1", flag
     that as a defect to fix, add a real country selector)
   - Response shape backend returns (session_id, expiry)
   - The OTP-entry UI does not exist yet in the mock — design it fresh,
     matching the existing glassmorphic style (see login/code.html's
     .glass-panel, .input-glow, .btn-gradient classes — reuse them,
     don't invent a new visual language)
   - Request/response shape for OTP verify
   - Every error state the UI must show: wrong OTP, expired OTP, OTP
     locked after 3 attempts, network failure, rate-limited — none of
     these exist in the current mock, they must be designed net-new

4. TEST FIRST (RED): write tests for the API client / request-building
   logic and for the backend endpoint contract before wiring the actual
   button handlers. Run them, confirm they fail, show me real output.

5. IMPLEMENT (GREEN):
   - Backend: confirm the existing OTP endpoints match the contract from
     step 3 (adjust if the reference check in step 2 surfaced a gap)
   - Frontend: replace the dead type="button" handlers with real fetch
     calls to the backend, wire loading/disabled states on the buttons
     while a request is in flight, wire every error state from step 3
     to actual UI feedback (not silent failure)
   - Build the missing OTP-entry screen/step now, reusing the login
     screen's existing visual components
   Run tests again, show me real passing output.

6. GATES: ruff, mypy --strict, bandit (this slice touches auth — bandit
   is mandatory, not optional). Fix every real finding, show before/after
   output.

7. REVIEW.md: append the real RED/GREEN/gate output for this slice, plus
   an explicit list of what's still not covered (e.g. if social login
   OAuth wiring isn't done in this pass, say so, don't imply it's done).

Stop after step 7. Do not touch search/seat/checkout screens in this pass.

Slice for this pass: Login frontend-backend integration (OTP request +
verify + missing OTP-entry screen)
Scope: login/code.html wiring only — the send-OTP button, the new
OTP-entry step, and the two backend endpoints they call
Folder: Day4/ (or wherever the real login backend currently lives — tell
me the path if it's not in Day4/)
