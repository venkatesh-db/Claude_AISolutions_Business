Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

Task: connect the frontend to the backend for <SLICE_NAME> and RUN IT LIVE —
not a code review, not a plan, an actual working system I can click through
in a browser with real data in the real database at the end.

Follow this exact sequence, in order. Do not skip steps, do not claim a
step is done without showing the real command output that proves it.

1. READ BEFORE BUILDING. Read the actual frontend markup and the actual
   backend code that currently exist for this slice, in full, before
   changing anything. State what you found — don't assume either side's
   shape. If a directory or file you expect is missing, STOP and say so
   explicitly before reconstructing anything — do not silently rebuild
   from memory without flagging that the source was missing and why that
   matters.

2. STAND UP REAL INFRA, DON'T MOCK IT. If the stack needs Postgres/Redis/
   Kafka, bring up the real services (Docker Compose or equivalent) — do
   not substitute an in-memory fake for "speed." Check for and resolve
   port conflicts explicitly:
   - Before binding any port, check what's already listening on it
     (`lsof -nP -iTCP:<port> -sTCP:LISTEN`).
   - If something else already owns it — a native service, an unrelated
     process from another project — do NOT kill it blindly. Remap our
     service to a free port instead (compose override file, or an env
     var), and say what you found and why you remapped rather than reused
     the default.
   - Run real migrations against the real instance. Confirm schema exists
     before moving on (`\dt` or equivalent), don't assume the migration
     succeeded from exit code alone.

3. START BOTH SIDES, CONFIRM HEALTH. Start the backend, curl its health
   endpoint and confirm a real 200. Serve the frontend statically. Confirm
   both are reachable before touching the browser.

4. DRIVE IT LIKE A REAL USER, IN THE BROWSER. Use the browser tool to
   actually click through the flow — type the input a real user would
   type, click the real buttons, read the real network requests. Do not
   fabricate what the screen would show — take real screenshots. If an
   automation quirk stops literal typed keystrokes from landing correctly
   (common with auto-advancing per-character inputs), fix it by setting
   the DOM value directly and dispatching a real `input` event — but only
   as an input-delivery workaround, never to fake a result. Every request
   that matters (e.g. "send OTP", "verify OTP") must be confirmed via the
   network tab or the server log, not assumed from the UI alone.

5. WHEN SOMETHING BREAKS, FIX IT FOR REAL, SHOW THE PROOF. A live run
   surfaces real bugs static review won't (missing transitive deps,
   silent port shadowing, partial-failure states). When you hit one:
   - Show the actual error (curl output, server log, stack trace)
   - Fix it
   - Re-run and show the actual passing result
   - If the bug reveals a deeper gap (e.g. a state that can't recover from
     a partial failure), log it explicitly as a known gap, don't quietly
     patch around it and move on as if it never happened

6. VERIFY THE END STATE AT THE DATA LAYER, NOT JUST THE UI. A success
   screen is not proof. Query the real database directly (psql or
   equivalent) and show the actual row(s) that resulted from the actual
   user action. If nothing changed at the data layer, the slice isn't
   actually working, no matter what the screen shows.

7. WRITE THE REVIEW LOG. Create/append a review doc for this live run
   covering: what infra was stood up and any conflicts resolved, what
   broke and how it was fixed (with real output), the end-to-end proof
   (browser steps + real DB query result), and an explicit "what this
   does NOT cover" section — missing tests, missing gate runs, features
   not rebuilt, known gaps not fixed in this pass.

Never report a live-run task as complete based on "the code should work" —
only based on what you actually ran and actually observed.

Slice for this pass: <SLICE_NAME>
Frontend entry point: <path to the html/page>
Backend entry point: <path to the FastAPI app / router>
Folder: <e.g. Day5/, or the real project path>
