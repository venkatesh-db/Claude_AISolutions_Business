# Review Pass — Slice 1: FlightSearchRequest

Methodology: verify-before-generate, vertical slice, RED → GREEN →
gates → review. One slice only (`FlightSearchRequest`), per this
session's agreed unit size.

## RED (test written first, run against no implementation)
```
$ PYTHONPATH=src python -m pytest tests/ -q
ModuleNotFoundError: No module named 'international_smile.flight_search'
1 error in 0.11s
```
Confirms `tests/test_flight_search.py` was not written to fit existing
code — the module did not exist when the test suite was first run.

## GREEN (implementation added, same tests re-run unchanged)
```
$ PYTHONPATH=src python -m pytest tests/ -v
11 passed in 0.07s
```
All 11 cases pass: observed-IndiGo defaults (round-trip, one-way,
multi-city, INR default), the 4 domain-boundary rejections
(missing return date on round-trip, return-before-departure, same
origin/destination, zero adults), the [Inferred]-flagged adult cap,
IATA normalization, and optional promo code.

## Quality gates (matches the project's stated stack: ruff, mypy --strict)
```
$ ruff check src/ tests/
All checks passed!

$ mypy --strict src/international_smile/flight_search.py
Success: no issues found in 1 source file
```
One real finding during this pass: `ruff` flagged `UP037` — a quoted
forward-reference type annotation (`-> "FlightSearchRequest"`) that
Python 3.14 no longer requires quoting for. Fixed in
`src/international_smile/flight_search.py` before this doc was
finalized — not left as a "future cleanup," per the coding-style rule
against unfinished half-fixes.

## What this slice does and does not cover

**Covered, with evidence:**
- Field shapes match what was live-observed on `goindigo.in` this
  session (see `DOMAIN_KNOWLEDGE.md` §1) — not memorized/assumed.
- Every validation rule has either an [Observed] or explicitly-flagged
  [Inferred] source in `DOMAIN_KNOWLEDGE.md` §3 — no unlabeled claims.
- Gates green, tests green, RED step proven before GREEN.

**Not covered — do not treat this slice as "the search feature done":**
- No FastAPI route wraps this model yet — it's a Pydantic contract only.
- The 4 conflicts logged in `DOMAIN_KNOWLEDGE.md` §2 (multi-city scope,
  special-fare programs, pay-with-points, promo-code placement) are
  still open product decisions, not resolved by this code.
- No live-observed IndiGo *error response* was captured for any invalid
  search (the [Inferred] flag in §3) — the rejection messages here are
  reasonable defaults, not confirmed against the real product's actual
  validation copy/behavior.

## Next slice (not started)
Per the agreed methodology, the next unit is one more thin slice — e.g.
`SeatLockRequest` or the OTP endpoint — each repeating this same
RED → GREEN → gates → review sequence, not a jump to building the whole
funnel at once.
