Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

We work in single verified vertical slices, never big-bang generation.
This slice already has a tested contract — Day4/src/international_smile/
flight_search.py (FlightSearchRequest, 11 passing tests, gates clean, see
Day4/REVIEW.md). This pass wires that contract into a real FastAPI route,
a minimal search response, and a real frontend screen, then runs it live —
following the same process as the Login slice.

Follow this exact sequence, in order. Do not skip steps, do not claim a
step is done without showing real command output.

1. READ FIRST. Read Day4/src/international_smile/flight_search.py and
   Day4/DOMAIN_KNOWLEDGE.md §1-2 in full before writing the route. Confirm
   the 4 open conflicts logged there (Multi City in scope? special-fare
   programs? pay-with-points? promo-code placement?) — if still
   unresolved, ask before assuming an answer; do not silently pick one.

2. REFERENCE CHECK (5 min max): re-verify on goindigo.in what a real
   search RESPONSE looks like — result list shape, fields per flight,
   price display — since only the search REQUEST was verified so far, not
   the results page. Tag new findings [Observed] in DOMAIN_KNOWLEDGE.md.

3. TEST FIRST (RED): write a test for a new `SearchResult` /
   `FlightOption` Pydantic model and for the `POST /search/flights` route
   (using FastAPI's TestClient), before either exists. Run it, confirm it
   fails, show real output.

4. IMPLEMENT (GREEN):
   - Backend: add the route wrapping FlightSearchRequest, returning a
     small set of realistic mock flight options (no live GDS integration
     in this slice — flag that explicitly as a scope boundary, not
     implied as done)
   - Frontend: build search_flights.html adapted from
     stitch_modern_irctc_redesign/search_flights/code.html, rebranded
     International Smile, wired to the real endpoint (replace the dead
     "Search Flights" button with a real fetch call)
   Run tests again, show real passing output.

5. GATES: ruff, mypy --strict on the new code. Show output.

6. LIVE RUN: stand up backend + frontend together (reuse the running
   Postgres/Redis containers if still up, confirm with `docker ps` first
   rather than assuming), drive a real search in the browser (Delhi →
   Mumbai or similar), confirm the real network request/response, screenshot
   the rendered results.

7. REVIEW.md: append the real RED/GREEN/gate/live output, plus an
   explicit "what this does NOT cover" section — no live fare data, no
   persistence of search history, no pagination, whatever else is out of
   scope for this pass.

Stop after step 7. Do not touch select_flight/select_seat/checkout in
this pass.

Slice for this pass: Search Flights (request already contracted, this
pass adds the route + response + live-wired frontend)
Folder: Day4/
