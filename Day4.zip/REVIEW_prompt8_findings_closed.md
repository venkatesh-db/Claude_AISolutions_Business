# Prompt8 — Findings closed

Both HIGH findings from the code review of the Login slice are fixed,
verified, and re-run live. Real output below, not claimed.

## Finding 1 — hardcoded default JWT secret

**RED** (`backend/tests/test_config_security.py`):
```
tests/test_config_security.py::test_missing_jwt_secret_raises_at_import FAILED
  Failed: DID NOT RAISE RuntimeError
tests/test_config_security.py::test_explicit_jwt_secret_is_accepted FAILED
  AssertionError: assert 'dev-secret-c...in-production' == 'a-real-secret-from-env'
```

**Fix** (`backend/app/config.py`): `jwt_secret` is now a required field with
no default; `Settings()` instantiation is wrapped in try/except and raises
`RuntimeError("JWT_SECRET must be set in the environment...")` on
`ValidationError` instead of silently falling back to the old dev string.

**GREEN**:
```
tests/test_config_security.py::test_missing_jwt_secret_raises_at_import PASSED
tests/test_config_security.py::test_explicit_jwt_secret_is_accepted PASSED
```

## Finding 2 — unhandled race on user creation

**RED** (`backend/tests/test_auth_service_race.py`) — two concurrent DB
sessions racing the same SELECT-then-INSERT via `asyncio.gather` against
real Postgres (real I/O interleaving, not simulated):
```
AttributeError("module 'app.services.auth_service' has no attribute '_get_or_create_user'")
```
(the helper didn't exist yet at RED time — confirms the test targets the
not-yet-written fix, not the old inline code.)

**Fix** (`backend/app/services/auth_service.py`): extracted
`_get_or_create_user(db, phone)`. On the losing side of a race, the DB's
existing unique constraint on `phone` raises `IntegrityError` on flush —
now caught, session rolled back, and the winner's row re-fetched, instead
of surfacing as an unhandled 500.

**GREEN**:
```
tests/test_auth_service_race.py::test_concurrent_get_or_create_user_does_not_raise PASSED
```

## Full suite + gates, after both fixes

```
$ pytest tests/ -v
3 passed

$ ruff check app/ tests/
All checks passed!

$ mypy --strict app/
Success: no issues found in 15 source files

$ bandit -r app/
No issues identified. (0 Low / 0 Medium / 0 High)
```

Two real mypy findings surfaced and were fixed properly (not suppressed)
along the way: `Redis[str]` was missing its generic type argument in
`redis_client.py` (fixing that also made three now-genuinely-unused
`# type: ignore[misc]` comments in `auth_service.py` removable), and the
Redis `hset` mapping was passing an `int` (`0`) where the `str`-typed
client expects a string — a real latent type bug beyond just satisfying
mypy, now `"0"`.

## Live re-verification (not just unit tests)

1. Backend restarted with a real random `JWT_SECRET` (not the old dev
   default) via env var — confirms the fix is enforced, not just testable.
2. Real browser click-through: `+919123456780` → real OTP `750006` read
   from the backend log → verified → "You're in." success screen.
3. Real Postgres row confirmed via direct `psql`:
   ```
   id=ec9b17b9-b05e-44cb-97f9-79f078c1692c  phone=+919123456780
   ```

## What this pass does NOT cover

- The concurrency test exercises the DB-layer race directly
  (`_get_or_create_user`); it does not simulate two real concurrent
  browser sessions hitting `/auth/otp/verify` with the *same* OTP session
  (that would require the Redis OTP-key race too, not just the DB race —
  out of scope for this pass, which targeted the two findings as filed).
- The separately-documented OTP partial-failure gap (Redis key deleted
  before token issuance, from `REVIEW_login_live.md`) is still open — not
  one of the two findings this pass was scoped to close.
