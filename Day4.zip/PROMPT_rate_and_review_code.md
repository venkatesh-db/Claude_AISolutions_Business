Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

Task: rate and review the code for <SLICE_NAME>. Do not summarize what the
code does — I can read it. Find what's actually wrong with it, cite exact
locations, and give a justified rating. No vague praise, no "looks good
overall" without evidence.

Follow this exact process:

1. READ THE ACTUAL FILES. List every file in scope for this slice. Read
   each one in full before writing any finding — don't review from memory
   of having written it earlier in the conversation.

2. FIND REAL DEFECTS, EACH WITH:
   - Exact file:line citation
   - Severity: CRITICAL (data loss / security breach / silent corruption)
     / HIGH (real bug that will trigger in production, or a real security
     default that's wrong) / MEDIUM (a real gap, lower likelihood or
     impact) / LOW (style/maintainability, not a functional bug)
   - The concrete failure scenario: what real input or timing triggers it,
     not a hypothetical
   - What the fix should be, in one sentence — not the full fix unless
     asked

   Check specifically for, don't skip these categories:
   - Hardcoded secrets or insecure defaults (a secret with a fallback
     value instead of a required env var is a finding, even if it's
     labeled "dev-only")
   - Check-then-act races (a SELECT followed by an INSERT/UPDATE with no
     transaction/locking/upsert between them — this is the single most
     common defect class in this codebase's history, per
     DOMAIN_KNOWLEDGE.md and the cartsvc reference doc; look for it
     explicitly in every service function that reads then writes)
   - PII or secrets (OTP codes, tokens, phone numbers, card data) logged
     in plaintext, even behind a "demo-only" comment
   - Unhandled exceptions that would surface as a raw 500 instead of a
     domain-meaningful error
   - Client-side-only validation with no server-side re-validation, or
     the reverse (server validation with client validation duplicated and
     able to drift)
   - Money/currency handled as float instead of int minor-units or Decimal
   - Missing idempotency on any mutating endpoint that a client could
     plausibly retry (double-tap, network retry)

3. DO NOT FLAG what's actually fine just to pad the list. If the state
   machine, layering, or HTTP status code choices are correct, say so
   briefly and move on — don't invent nitpicks to seem thorough.

4. GIVE A NUMERIC RATING (out of 10) with a one-paragraph justification
   that explicitly ties the number to the findings above — e.g. "solid
   shape, dragged down by N real security/concurrency findings that the
   project's own gates (ruff/mypy --strict/bandit) would have caught had
   they been run." The rating must be defensible from the findings list,
   not a separate vibe.

5. END WITH ONE QUESTION: which finding(s), if any, should be fixed right
   now before moving to the next slice, versus logged and deferred.

Do not use the ReportFindings tool unless explicitly told to — respond in
plain text unless a code-review skill/command says otherwise.

Slice for this pass: <SLICE_NAME>
Files in scope: <list exact paths — do not let scope silently expand to
the whole codebase>
