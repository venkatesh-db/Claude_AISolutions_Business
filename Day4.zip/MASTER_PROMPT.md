# International Smile — Master Slice Prompt

One prompt, one slice, every time. Copy the block below, fill in the 4
blanks at the bottom, paste to Claude. This replaces chaining Prompt1
through Prompt9 individually — it's the distilled process those runs
proved out.

---

## PROMPT TO PASTE

```
Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit, pip-audit.

We work in single verified vertical slices, never big-bang generation.
One slice per pass. Do not touch screens/endpoints outside the named
scope. Do not claim a step is done without showing the real command
output that proves it — no step in this process is satisfied by
description alone.

1. READ FIRST. Read whatever frontend markup and backend code already
   exist for this slice, in full, before changing anything. State what
   you found. If something you expect is missing (a file, a directory),
   STOP and say so explicitly before reconstructing it — do not silently
   rebuild from memory without flagging why the source was missing.

2. REFERENCE CHECK (5 min max, only if the slice has real-world domain
   fields/behavior not yet verified). Check live against a real reference
   product (IndiGo at goindigo.in, or MakeMyTrip/Goibibo) using the
   browser tool. Do not rely on memorized/trained knowledge of these
   products — observe live.

3. DOMAIN_KNOWLEDGE.md: write or extend it for this slice. Every field/
   rule tagged with evidence source:
   [Observed] live this session, cite exact element/text.
   [Stitch] from stitch_modern_irctc_redesign/, cite file:line.
   [Inferred] standard pattern, not verified — must be labeled, never
   presented as fact.
   Log any conflict between reference product and Stitch mock as an open
   decision — never silently pick one.

4. TEST FIRST (RED). Write the test(s) for this slice's contract before
   any implementation exists. Run them. Confirm real failure output.

5. IMPLEMENT (GREEN). Minimal code to pass the tests from step 4 — no
   speculative fields, no unused abstractions, no scope creep past the
   named slice. Run tests again, show real passing output.

6. GATES. ruff, mypy --strict, bandit (mandatory if the slice touches
   auth/payment/PII), pip-audit if new dependencies were added. Fix every
   real finding — never suppress or ignore. Show real before/after output.

7. LIVE RUN, if this slice has a frontend+backend pair to wire (skip this
   step only for pure-contract slices with no UI/endpoint yet):
   - Stand up real infra (Docker Postgres/Redis) — check what's already
     running first (`docker ps`), don't assume nothing is up
   - Check for port conflicts before binding (`lsof -nP -iTCP:<port>
     -sTCP:LISTEN`) — remap to a free port if something else already owns
     the default, never kill an unrelated process blindly
   - Run real migrations, confirm schema (`\dt` or equivalent)
   - Start both sides, confirm health via curl, not assumption
   - Drive it like a real user in the browser — real input, real clicks,
     real network requests/logs read as proof
   - When something breaks, show the real error, fix the real cause,
     re-verify for real — if it reveals a deeper gap, log it explicitly,
     don't quietly patch around it
   - Verify the end state at the data layer (real DB query), not the UI
     alone

8. REVIEW.md: append real RED/GREEN/gate/live output for this slice, plus
   an explicit "what this does NOT cover" list — don't let a slice get
   reported as "the feature is done" when it's one path through it.

9. SELF-REVIEW (only if asked, or before considering the slice closed).
   Re-read the actual files just written. Find real defects — file:line,
   severity (CRITICAL/HIGH/MEDIUM/LOW), concrete failure scenario, one-
   sentence fix. Check specifically for: hardcoded secrets/insecure
   defaults, check-then-act races (SELECT-then-write with no lock/upsert
   — the single most common defect class in this project's history),
   PII/secrets logged in plaintext, unhandled exceptions surfacing as raw
   500s, validation duplicated/drifted between client and server, float
   money math, missing idempotency on retryable mutations. Don't pad the
   list with nitpicks. Give a numeric rating (out of 10) that traces
   directly to the findings, not a separate vibe. Ask which findings to
   fix now vs. defer.

Stop after step 8 (or step 9 if run). Do not start the next slice until
told to.

Slice for this pass: <SLICE_NAME>
Scope: <exact files/endpoints/screens in scope — no silent expansion>
Folder: <e.g. Day5/, or wherever this slice's code lives>
Prior findings to close first, if any: <list, or "none">
```

---

## Fill-in guide

- `<SLICE_NAME>` — one thing. `Login OTP`, `Search Flights route`,
  `SeatLockRequest`, `Checkout payment intent`. Never "the login flow" or
  "checkout" as a whole multi-screen unit.
- `<Scope>` — be explicit enough that scope can't silently creep. If it's
  contract-only (no UI/endpoint yet), say so — step 7 gets skipped.
- `<Folder>` — new slice, new day-folder, so REVIEW.md/DOMAIN_KNOWLEDGE.md
  don't collide across slices the way they'd otherwise need merging.
- `<Prior findings to close first>` — check the most recent REVIEW*.md
  before starting a new slice; unclosed HIGH/CRITICAL findings on code
  this slice depends on should block, not run in parallel silently.

## Why each step exists (so nobody strips one out as "extra process")

- Step 1 caught a whole directory disappearing mid-session — would have
  been silently papered over otherwise.
- Step 2 caught real product fields (UPI, GSTIN, Multi City) that neither
  the Stitch mock nor memorized knowledge had.
- Steps 4-6 are what makes "done" mean something — a slice with no RED
  step is a slice where you can't prove the test would ever have failed.
- Step 7 is what caught two real bugs (a missing `greenlet` dependency, a
  Postgres port silently shadowed by a native service) that no amount of
  static review would have surfaced.
- Step 9 is what caught a hardcoded JWT secret default and an unhandled
  concurrency race — both real, both would have shipped invisibly under a
  "looks good" pass.

Every step here maps to something that actually broke or would have
shipped wrong in this project already. None of it is theoretical.
