Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

Task: connect the frontend to the backend for Login (OTP request → verify)
and RUN IT LIVE — not a code review, not a plan, an actual working system
I can click through in a browser with real data in the real database at
the end.

Follow this exact sequence, in order. Do not skip steps, do not claim a
step is done without showing the real command output that proves it.

1. READ BEFORE BUILDING. Read the actual frontend markup and the actual
   backend code that currently exist for this slice, in full, before
   changing anything. State what you found — don't assume either side's
   shape. If a directory or file you expect is missing, STOP and say so
   explicitly before reconstructing anything.

2. STAND UP REAL INFRA, DON'T MOCK IT. Bring up real Postgres + Redis
   (Docker Compose). Check for port conflicts before binding
   (`lsof -nP -iTCP:<port> -sTCP:LISTEN`) — if something else already
   owns the default port, remap to a free one rather than killing an
   unrelated process. Run real Alembic migrations, confirm schema exists
   (`\dt`) before moving on.

3. START BOTH SIDES, CONFIRM HEALTH. Start the FastAPI backend, curl
   `/health`, confirm a real 200. Serve the frontend statically. Confirm
   both reachable before touching the browser.

4. DRIVE IT LIKE A REAL USER, IN THE BROWSER. Enter a real phone number,
   click Send OTP for real, read the real network request. Read the real
   OTP from the backend log (this demo logs it instead of sending SMS —
   never fabricate the code). Enter it in the OTP boxes, click Verify for
   real.

5. WHEN SOMETHING BREAKS, FIX IT FOR REAL, SHOW THE PROOF. If verify
   fails, show the actual curl/server-log error, fix the real cause
   (e.g. a missing dependency), restart, and re-run for real. If the bug
   reveals a deeper state-machine gap, log it explicitly — don't quietly
   patch and move on as if it never happened.

6. VERIFY THE END STATE AT THE DATA LAYER. Query Postgres directly
   (`psql`) and show the actual `users` / `refresh_tokens` rows created by
   the actual click-through. A success screen alone is not proof.

7. WRITE THE REVIEW LOG. What infra was stood up, what conflicts were
   resolved, what broke and how it was fixed (with real output), the
   end-to-end proof, and an explicit "what this does NOT cover" section.

Slice for this pass: Login OTP request → verify
Frontend entry point: Day4/frontend/login.html
Backend entry point: Day4/backend/app/main.py (auth router:
Day4/backend/app/api/routes_auth.py)
Folder: Day4/
