Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

Task: close two known findings from the Login slice review
(Day4/REVIEW_login_live.md and the code review that followed it) before any
new slice starts. Do not touch other screens/endpoints.

Findings to close:

1. HIGH — hardcoded default JWT secret
   File: Day4/backend/app/config.py:11
   `jwt_secret: str = "dev-secret-change-in-production"`
   Fix: require JWT_SECRET from the environment with no silent fallback —
   raise at startup if unset, instead of defaulting to a value that could
   ship unnoticed.

2. HIGH — unhandled race condition on user creation
   File: Day4/backend/app/services/auth_service.py:96-101
   SELECT-then-INSERT with no handling for the concurrent-insert case; the
   DB unique constraint on `phone` will raise IntegrityError on a race,
   currently unhandled, surfaces as a raw 500.
   Fix: catch the IntegrityError and re-fetch the existing user, or use an
   upsert (INSERT ... ON CONFLICT) instead of check-then-insert.

Follow this sequence:

1. RED: write a test that reproduces each finding before fixing it.
   - For finding 1: a test asserting the app fails to start / raises when
     JWT_SECRET is unset (don't just assert the default string is gone —
     prove the unsafe path is actually blocked).
   - For finding 2: a test that simulates two concurrent `verify_otp`
     calls for the same new phone number and asserts both return the same
     user with no unhandled exception.
   Run both, confirm they fail against the current code, show real output.

2. GREEN: implement the minimal fix for each. Re-run the same tests, show
   real passing output.

3. GATES: ruff, mypy --strict, bandit — bandit is mandatory here since
   both findings are security-adjacent. Show before/after output if
   anything is flagged.

4. LIVE RE-VERIFY: re-run the actual login flow live (per
   Day4/PROMPT_login_run_live_FILLED.md steps 3-6) to confirm the fix
   didn't break the working happy path. Real browser click-through, real
   DB row check, not just the unit tests.

5. REVIEW.md: append to Day4/REVIEW_login_live.md — what was fixed, the
   real RED/GREEN/gate output, and confirmation the live flow still works
   post-fix.

Do not start Search Flights or any other slice until this is done and
confirmed.
