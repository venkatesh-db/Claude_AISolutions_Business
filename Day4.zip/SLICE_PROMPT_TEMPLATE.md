# International Smile — Slice Prompt Template

Copy this whole block, fill in the 4 blanks, paste to Claude to start a new
slice. Don't skip steps or ask for more than one slice at a time — the
point of this template is to prevent big-bang generation.

---

## PROMPT TO PASTE

```
Role: Principal architect + full-stack engineer, travel domain.
Project: International Smile (flight booking). Stack: FastAPI, Pydantic v2,
PostgreSQL/SQLAlchemy 2.x/Alembic, Redis, Celery, Kafka, pytest, ruff,
mypy --strict, bandit.

We work in single verified vertical slices, never big-bang generation.
Methodology for this slice, follow it exactly, in order:

1. REFERENCE CHECK (5 min max): before writing any contract, verify the
   real field/behavior for <SLICE_NAME> against a live reference product
   (IndiGo at goindigo.in, or MakeMyTrip/Goibibo if IndiGo doesn't cover
   it). Use the browser tool. Do not rely on memorized/trained knowledge
   of these products — observe the live page directly.

2. DOMAIN_KNOWLEDGE.md: write or extend the domain doc for this slice.
   Every field/rule must be tagged with its evidence source:
   - [Observed] — captured live from a real product this session, cite
     the exact element/text seen.
   - [Stitch] — from our UI mockup (stitch_modern_irctc_redesign/), cite
     file:line.
   - [Inferred] — standard domain pattern, not verified live. Must be
     labeled, never presented as fact.
   If the reference product's behavior conflicts with the Stitch mock,
   log it as an open conflict, do not silently pick one.

3. TEST FIRST (RED): write the pytest test file for <SLICE_NAME> before
   any implementation exists. Run it. Confirm it fails
   (ModuleNotFoundError or equivalent). Show me the actual failing output.

4. IMPLEMENT (GREEN): write the minimal Pydantic v2 model / FastAPI route
   / service function needed to make the tests in step 3 pass. Nothing
   more — no speculative fields, no unused abstractions. Run the tests
   again, show me the actual passing output.

5. GATES: run ruff, mypy --strict (and bandit if the slice touches
   auth/payment/PII). Fix every real finding — do not suppress or ignore.
   Show me the actual command output, before and after any fix.

6. REVIEW.md: write/append a review log for this slice with the real
   RED output, real GREEN output, real gate output, and an explicit list
   of what this slice does NOT cover yet (don't let one slice get
   reported as "the feature is done").

Stop after step 6. Do not start the next slice, do not touch other
screens/endpoints, until I say go.

Slice for this pass: <SLICE_NAME>
Scope: <ONE ENDPOINT / ONE MODEL / ONE SCREEN'S INPUT CONTRACT — name it>
Folder: <e.g. Day5/, or the real project path>
```

---

## Fill-in guide

- `<SLICE_NAME>` — one thing only. Examples that are correctly sized:
  `Login OTP request`, `SeatLockRequest`, `AddOnSelection`,
  `CheckoutPaymentIntent`. Examples that are WRONG sized (reject if a
  coder writes these in): "the login flow", "checkout", "the whole
  booking system".
- `<ONE ENDPOINT / ONE MODEL / ...>` — be explicit that this is a single
  Pydantic contract or a single FastAPI route, not a screen's worth of
  UI, not a service layer, not a DB migration, unless that's genuinely
  the whole scope of the slice.
- `<Folder>` — keep each day/slice in its own folder like `Day4/` did, so
  REVIEW.md and DOMAIN_KNOWLEDGE.md don't collide across slices.

## Why this template exists (context for whoever inherits this)

Earlier in this project, Claude was asked to generate the whole domain
requirement doc (states, API contracts, event schema) in one pass before
any live verification happened. It produced plausible-looking content
that silently mixed real observed facts with inferred industry patterns,
with no way to tell which was which. That produced a doc that read as
authoritative but wasn't fully trustworthy — the actual failure mode
behind "code quality comes out wrong."

This template forces three fixes into every slice, permanently:
1. Live verification before any contract is written (catches wrong
   assumptions before they get encoded in code).
2. Explicit evidence tagging (so nobody mistakes a guess for a fact).
3. Test-first, one slice at a time (so a wrong slice is caught in
   minutes, not discovered three screens later).

## Example of a correctly-run slice

See `Day4/DOMAIN_KNOWLEDGE.md`, `Day4/tests/test_flight_search.py`,
`Day4/src/international_smile/flight_search.py`, and `Day4/REVIEW.md` —
that's what step 1-6 output looks like when done right, including the
real RED/GREEN/gate command output as proof, not a claim.
