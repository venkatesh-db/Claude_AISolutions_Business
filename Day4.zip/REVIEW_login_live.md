# Review — Login frontend + backend, live-run

Slice: Login OTP request → verify, real FastAPI backend + real Postgres/Redis
+ real browser-driven frontend. Not a unit-test slice — this is the actual
running system, end to end.

## Context: why this was rebuilt inside Day4/

The original implementation lived in `irctc-travel-app/` (backend +
frontend). Mid-session, while running this exact live test, that entire
directory disappeared from disk — not removed by any command run in this
session (verified: no `rm`/`mv`/destructive git op was issued against it).
Cause unconfirmed; flagged to the user directly, not silently worked around.
The backend/schema/frontend logic below is a reconstruction from the exact
file contents read earlier in this session (`routes_auth.py`, `schemas/
auth.py`, `auth_service.py`, `login.html`), rebranded from "Aetheris" to
"International Smile" per the user's brand decision, not re-derived from
memory or guesswork.

## Infra brought up live

- Docker Desktop was not running; started it, confirmed daemon ready.
- `docker compose up -d postgres redis` (irctc-travel-app/docker-compose.yml,
  still on disk / unaffected).
- **Real conflict found and fixed**: host port 5432 was already bound by a
  native Homebrew Postgres (`127.0.0.1:5432`, PID 565) — Docker's container
  was silently shadowed, not failing loudly. Fixed via
  `docker-compose.override.yml` remapping to `5433:5432`, not by touching
  the user's existing native Postgres service.
- **Same class of conflict on port 8000/8001**: unrelated pre-existing
  processes (PIDs 11394/11396, a bus-search API, not ours) already owned
  those ports on `127.0.0.1`. Moved our backend to port 8123 instead of
  killing another process blindly.
- Alembic migrations applied against the correct (5433) instance —
  `0001, initial schema: users, refresh_tokens, orders`.

## Real bug found and fixed during the live run

`ValueError: the greenlet library is required to use this function. No
module named 'greenlet'` — SQLAlchemy's async engine needs `greenlet`
installed explicitly; it's a transitive requirement not auto-pulled by the
base install in this venv. First `/auth/otp/verify` call failed with a
real HTTP 500, confirmed via direct `curl`, not assumed. Fixed by
installing `greenlet` and restarting the backend. This is exactly the kind
of finding step 5 (GATES) exists to catch before calling a slice done — it
was caught here by live execution instead, because this was a live-run
task, not a unit-test-only pass.

## Secondary real finding: partial-failure state gap

Because of the greenlet crash above, one verify attempt failed **after**
`auth_service.verify_otp` had already deleted the Redis OTP session key but
**before** the token pair was issued — leaving that OTP session
unrecoverably `otp_expired` on retry, with no order/booking-equivalent
reconciliation path. This is a live, reproduced instance of the exact
"payment succeeds but issuance fails" class of bug flagged as a required
state-machine case in the earlier domain requirement doc (§2.2 there) —
now confirmed as a real gap in `auth_service.py`, not just a theoretical
OTA pattern. Not fixed in this pass (out of scope for a login slice); flag
for a dedicated slice on OTP-session recovery.

## End-to-end proof (not claimed — verified)

1. Browser: entered `+919876543210`, clicked Send One-Time Code.
2. Backend log: `OTP for +919876543210 (session ...): 922067` — real code
   generated server-side, never sent to or read by the frontend except via
   the demo log (production would be an SMS gateway, per the code comment
   already in `auth_service.py`).
3. Browser: entered the real 6-digit code, clicked Verify & Continue.
4. UI transitioned to the success state: "You're in. Your journey with
   International Smile begins." (brand-corrected from the original hidden
   stub's "Avia Luxe" copy found in the Stitch mock).
5. Confirmed via direct `psql` query against the container — not inferred
   from the UI alone:
   ```
   users:           id=42bc05b4-... phone=+919876543210
   refresh_tokens:  2 rows, user_id=42bc05b4-..., revoked=false
   ```

## What this run does NOT cover

- No automated tests were written for this slice (unlike `FlightSearchRequest`
  in Day4 — that one followed full RED→GREEN→gates; this one was a live
  systems-integration run under time pressure, per the user's explicit ask
  to "connect frontend + backend, implement the feature and live it").
  This is a gap, not a finished slice — pytest coverage for the auth
  endpoints should be added before this is considered production-ready.
- ruff/mypy --strict/bandit have not been run against `Day4/backend/` yet.
- Social login (Apple/Google) buttons from the original Stitch mock are not
  present in this reconstructed `login.html` — only the OTP path was
  rebuilt, matching what actually existed as working code before the
  directory loss.
- The OTP-session partial-failure gap above is documented, not fixed.
